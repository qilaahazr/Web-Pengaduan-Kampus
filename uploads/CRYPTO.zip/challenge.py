#!/usr/bin/env python3
"""
Periodic XOR + Vigenere Noise Challenge

Hint: The key is classified... literally.
Hint: What makes noise? Hmm...
"""

from secret import FLAG

# HINT: It's a word for keeping things hidden (6 letters)
PERIODIC_KEY = b"secret"

# HINT: Random unwanted data that干扰 the signal (5 letters)
VIGENERE_KEY = b"noise"

def periodic_xor(data: bytes, key: bytes) -> bytes:
    result = []
    for i, b in enumerate(data):
        result.append(b ^ key[i % len(key)])
    return bytes(result)

def vigenere_noise(data: bytes, key: bytes) -> bytes:
    result = []
    for i, b in enumerate(data):
        noise = key[i % len(key)]
        result.append((b + noise) % 256)
    return bytes(result)

def encrypt(flag: str) -> bytes:
    plaintext = flag.encode()
    xored = periodic_xor(plaintext, PERIODIC_KEY)
    encrypted = vigenere_noise(xored, VIGENERE_KEY)
    return encrypted

if __name__ == "__main__":
    ciphertext = encrypt(FLAG)
    print(ciphertext.hex())