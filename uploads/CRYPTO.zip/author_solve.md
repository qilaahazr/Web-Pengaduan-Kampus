# Author Solve - Periodic XOR + Vigenere Noise

## Challenge Overview

Given `clustered.txt` - a messy system dump containing scattered data.

## Finding the Ciphertext

Located in the Memory Dump section:
```
Memory Dump - offset:0x0000
=================================================================
8f9d997c7ab570bdc67bc2869590b86ea96bb567be8bbf79a5a87cabc76cae87
=================================================================
```

## Finding the Keys

The hex values are scattered across different system logs:

### Key (from syslog):
```
Mar 15 14:32:16 hostname encoder[2048]: Key loaded from 0x73:65:63:72:65:74
```
Hex: `73:65:63:72:65:74` → ASCII: "secret"

### Modifier/Noise (split across dmesg):
```
[    2.345678] kernel: Loaded driver with id: 6E:6F:69:73
[  124.567890] kernel: Signal modifier: 65 added
```
Combine: `6E:6F:69:73:65` → ASCII: "noise"

## Encryption Process

```
flag → periodic XOR with "secret" → vigenere noise with "noise" → ciphertext
```

### Step 1: Periodic XOR
- Key: "secret" (repeats every 6 bytes)
- Operation: XOR each byte with key[i % key_length]

### Step 2: Vigenere Noise
- Key: "noise" (repeats every 5 bytes)
- Operation: (byte + key_byte) % 256

## Decryption (reverse order)

1. **Reverse Vigenere noise**: Subtract instead of add
2. **Reverse periodic XOR**: XOR again with same key

### Full Solution Script

```python
ciphertext = bytes.fromhex("8f9d997c7ab570bdc67bc2869590b86ea96bb567be8bbf79a5a87cabc76cae87")

# Reverse Vigenere noise
noised = []
for i, b in enumerate(ciphertext):
    noise = b"noise"[i % 5]
    noised.append((b - noise) % 256)
noised = bytes(noised)

# Reverse periodic XOR
plaintext = []
for i, b in enumerate(noised):
    key_byte = b"secret"[i % 6]
    plaintext.append(b ^ key_byte)

print(bytes(plaintext).decode())
# Output: RKS{p3r10d1c_x0r_v1g3n3r3_n01s3}
```

## Challenge Design Notes

- Keys scattered across different log types (syslog + dmesg)
- Modifier split into two parts requiring combination
- No explicit crypto terms used - just hex values and system terminology
- Solvers must dig through system noise to extract key components